import first_module
print("first module name is {}".format(__name__))

