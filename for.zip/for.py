my_list=[1,2,3,4,5,6,7,8,9,10]
for asdf in my_list:
    print(asdf)
    
my_list=[1,2,3,4,5,6]

list_sum=0
for num in my_list:
     list_sum=list_sum+num
print(list_sum)
my_list=[1,2,3,4,5]
for num in my_list:
   if num%2!=0:
      print(num)
my_list=[1,2,3,4,5,6,7,8,9]
for num in my_list:
    if num%2!=0:
        print("even numbers{}".format(num))
    else:
        print("odd numbers{}".format(num))
        
my_list="Hello world"
for letters in my_list:
    print("python")
t=(1,2,3,4,5)
for num in t:
    print(num)
list=[(1,2),(4,5),(2,6)]
for items in list:
    print(items)
    
d={'a':2,'b':4,'c':6}
for items in d.items():
    print(items)
    
    
