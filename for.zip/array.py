import numpy as np
  
my_list=[(1,2),(3,4),(5,0)]
np.array(my_list)
ar=np.array(my_list)
ar
mat=[(1,2,3,4),(2,3,4,0)]
np.mat(mat)
arr=np.mat(mat)
arr


np.zeros(3)
np.ones((4,2))

np.linspace(0,10,5)