from matplotlib import pyplot as plt

x=[1,2,3]
y=[4,6,9]
plt.plot(x,y)
plt.xlabel("days")
plt.ylabel("weeks")
plt.title("no. of days in a week")
plt.show()
