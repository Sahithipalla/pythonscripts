#print(__name__)
print("first module name is {}".format(__name__))

