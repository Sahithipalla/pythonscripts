n={"sai":39,"suppy":70,"sahi":25}
n
n["sai]
d={'f':100,'g':[1,2,3,4],'h':{'sai','he'}}
d['g'][2]
d['h']
d['i']=200
d
d['g']='sai'
d
d.items()
d.keys()
d.values()

