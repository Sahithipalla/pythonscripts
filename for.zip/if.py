 if 2>5:
    print("True")
else:
    print("False")
drink="tea"
     
if drink=="coffee":
    print("Humanity runs on coffee")
elif drink=="coke":
    print("coke is fuel for prgm")
elif drink=="tea":
    print("water is soul for earth")
else:
    print("you are free to select drink")

